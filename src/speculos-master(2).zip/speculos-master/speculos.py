#!/usr/bin/env python3
"""Launch Speculos emulator"""
from speculos.main import main


if __name__ == "__main__":
    main()
