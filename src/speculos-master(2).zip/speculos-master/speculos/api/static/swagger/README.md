This directory is automatically generated using instructions from ../../README.md.
